﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gray
{
	public partial class Form1 : Form
	{
        
        public Form1()
		{
			InitializeComponent();
		}

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap OriginalBitmap=null;
            string name = "All Files(*.*)|*.*|Bitmap File(*.bmp)|*.bmp|";
            name = name + "Gif File(*.gif)|*.gif|jpeg File(*.jpg)|*.jpg";
            openFileDialog1.Title = "타이틀";
            openFileDialog1.Filter = name;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string strName = openFileDialog1.FileName;

                OriginalBitmap = new Bitmap(Image.FromFile(strName));
            }

            pictureBox1.Image = OriginalBitmap;
        }

        private void 저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string savestrFilename;

            saveFileDialog1.Title = "이미지 파일저장...";
            saveFileDialog1.OverwritePrompt = true;
            saveFileDialog1.Filter = "JPEG File(*.jpg)|*.jpg|Bitmap File(*.bmp)|*.bmp";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                savestrFilename = saveFileDialog1.FileName;
                pictureBox2.Image.Save(savestrFilename);
            }
        }

        private void grayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(pictureBox1.Image);
            Color color;
            int brightness;
            for (int x = 0; x < bitmap.Width; x++)
                for (int y = 0; y < bitmap.Height; y++)
                {
                    color = bitmap.GetPixel(x, y);
                    brightness = (int)(0.299 * color.R + 0.587 * color.G + 0.114 * color.B);
                    bitmap.SetPixel(x, y, Color.FromArgb(brightness, brightness, brightness));

                }
            pictureBox2.Image = bitmap;

        }
    }
}
